<?php
/**
 * Template para post individual
 *
 * @package News_Soberano
 */

get_header();
?>

<main id="main" class="site-main single-post">
    <div class="container">
        <div class="row">
            <div class="col-main">
                <?php
                while (have_posts()) :
                    the_post();

                    // Incrementar visualizações
                    if (!is_preview()) {
                        news_soberano_set_post_views(get_the_ID());
                    }
                ?>

                    <article id="post-<?php the_ID(); ?>" <?php post_class('single-article'); ?>>

                        <!-- Categoria e Data -->
                        <div class="article-meta-top">
                            <?php
                            $categories = get_the_category();
                            if (!empty($categories)) :
                            ?>
                                <a href="<?php echo esc_url(get_category_link($categories[0]->term_id)); ?>" class="article-category">
                                    <?php echo esc_html($categories[0]->name); ?>
                                </a>
                            <?php endif; ?>
                        </div>

                        <!-- Título -->
                        <header class="article-header">
                            <h1 class="article-title"><?php the_title(); ?></h1>

                            <div class="article-meta">
                                <div class="meta-author">
                                    <?php echo get_avatar(get_the_author_meta('ID'), 40); ?>
                                    <div class="author-info">
                                        <span class="author-name">
                                            <?php _e('Por', 'news-soberano'); ?>
                                            <a href="<?php echo esc_url(get_author_posts_url(get_the_author_meta('ID'))); ?>">
                                                <?php the_author(); ?>
                                            </a>
                                        </span>
                                        <div class="meta-details">
                                            <time datetime="<?php echo get_the_date('c'); ?>">
                                                <?php echo get_the_date(); ?>
                                            </time>
                                            <span>•</span>
                                            <span><?php echo news_soberano_reading_time(); ?></span>
                                            <span>•</span>
                                            <span><?php echo number_format(news_soberano_get_post_views(get_the_ID())); ?> <?php _e('visualizações', 'news-soberano'); ?></span>
                                        </div>
                                    </div>
                                </div>

                                <!-- Compartilhamento Social -->
                                <div class="social-share">
                                    <span class="share-label"><?php _e('Compartilhar:', 'news-soberano'); ?></span>
                                    <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo urlencode(get_permalink()); ?>"
                                       target="_blank"
                                       rel="noopener noreferrer"
                                       aria-label="<?php esc_attr_e('Compartilhar no Facebook', 'news-soberano'); ?>"
                                       class="share-btn facebook">
                                        <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
                                            <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
                                        </svg>
                                    </a>
                                    <a href="https://twitter.com/intent/tweet?url=<?php echo urlencode(get_permalink()); ?>&text=<?php echo urlencode(get_the_title()); ?>"
                                       target="_blank"
                                       rel="noopener noreferrer"
                                       aria-label="<?php esc_attr_e('Compartilhar no Twitter', 'news-soberano'); ?>"
                                       class="share-btn twitter">
                                        <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
                                            <path d="M23.953 4.57a10 10 0 01-2.825.775 4.958 4.958 0 002.163-2.723c-.951.555-2.005.959-3.127 1.184a4.92 4.92 0 00-8.384 4.482C7.69 8.095 4.067 6.13 1.64 3.162a4.822 4.822 0 00-.666 2.475c0 1.71.87 3.213 2.188 4.096a4.904 4.904 0 01-2.228-.616v.06a4.923 4.923 0 003.946 4.827 4.996 4.996 0 01-2.212.085 4.936 4.936 0 004.604 3.417 9.867 9.867 0 01-6.102 2.105c-.39 0-.779-.023-1.17-.067a13.995 13.995 0 007.557 2.209c9.053 0 13.998-7.496 13.998-13.985 0-.21 0-.42-.015-.63A9.935 9.935 0 0024 4.59z"/>
                                        </svg>
                                    </a>
                                    <a href="https://wa.me/?text=<?php echo urlencode(get_the_title() . ' - ' . get_permalink()); ?>"
                                       target="_blank"
                                       rel="noopener noreferrer"
                                       aria-label="<?php esc_attr_e('Compartilhar no WhatsApp', 'news-soberano'); ?>"
                                       class="share-btn whatsapp">
                                        <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
                                            <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/>
                                        </svg>
                                    </a>
                                    <a href="mailto:?subject=<?php echo urlencode(get_the_title()); ?>&body=<?php echo urlencode(get_permalink()); ?>"
                                       aria-label="<?php esc_attr_e('Compartilhar por Email', 'news-soberano'); ?>"
                                       class="share-btn email">
                                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                            <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path>
                                            <polyline points="22,6 12,13 2,6"></polyline>
                                        </svg>
                                    </a>
                                </div>
                            </div>
                        </header>

                        <!-- Imagem Destacada -->
                        <?php if (has_post_thumbnail()) : ?>
                            <div class="article-featured-image">
                                <?php the_post_thumbnail('news-featured', array('alt' => get_the_title())); ?>
                            </div>
                        <?php endif; ?>

                        <!-- Conteúdo -->
                        <div class="article-content">
                            <?php the_content(); ?>

                            <?php
                            wp_link_pages(array(
                                'before' => '<div class="page-links">' . __('Páginas:', 'news-soberano'),
                                'after'  => '</div>',
                            ));
                            ?>
                        </div>

                        <!-- Tags -->
                        <?php if (has_tag()) : ?>
                            <div class="article-tags">
                                <strong><?php _e('Tags:', 'news-soberano'); ?></strong>
                                <?php the_tags('', ', ', ''); ?>
                            </div>
                        <?php endif; ?>

                        <!-- Box do Autor -->
                        <div class="author-box">
                            <?php echo get_avatar(get_the_author_meta('ID'), 80); ?>
                            <div class="author-box-content">
                                <h3 class="author-box-title">
                                    <a href="<?php echo esc_url(get_author_posts_url(get_the_author_meta('ID'))); ?>">
                                        <?php the_author(); ?>
                                    </a>
                                </h3>
                                <p class="author-box-bio"><?php echo get_the_author_meta('description'); ?></p>
                            </div>
                        </div>

                    </article>

                    <?php
                    // Posts Relacionados
                    $related_posts = new WP_Query(array(
                        'category__in'   => wp_get_post_categories(get_the_ID()),
                        'post__not_in'   => array(get_the_ID()),
                        'posts_per_page' => 3,
                        'orderby'        => 'rand',
                    ));

                    if ($related_posts->have_posts()) :
                    ?>
                        <div class="related-posts">
                            <h2 class="related-posts-title"><?php _e('Notícias Relacionadas', 'news-soberano'); ?></h2>
                            <div class="grid grid-3">
                                <?php
                                while ($related_posts->have_posts()) :
                                    $related_posts->the_post();
                                ?>
                                    <article class="news-card">
                                        <?php if (has_post_thumbnail()) : ?>
                                            <a href="<?php the_permalink(); ?>">
                                                <?php the_post_thumbnail('news-medium', array('class' => 'news-card-image lazyload')); ?>
                                            </a>
                                        <?php endif; ?>
                                        <div class="news-card-content">
                                            <h3 class="news-card-title">
                                                <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                                            </h3>
                                            <div class="news-card-meta">
                                                <span><?php echo get_the_date(); ?></span>
                                            </div>
                                        </div>
                                    </article>
                                <?php endwhile; ?>
                            </div>
                        </div>
                    <?php
                        wp_reset_postdata();
                    endif;
                    ?>

                    <?php
                    // Comentários
                    if (comments_open() || get_comments_number()) :
                        comments_template();
                    endif;
                    ?>

                <?php endwhile; ?>
            </div>

            <!-- Sidebar -->
            <?php if (is_active_sidebar('sidebar-1')) : ?>
                <aside class="col-sidebar">
                    <?php get_sidebar(); ?>
                </aside>
            <?php endif; ?>
        </div>
    </div>
</main>

<?php
get_footer();
