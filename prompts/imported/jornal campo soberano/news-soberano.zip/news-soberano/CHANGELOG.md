# Changelog - News Soberano Theme

Todas as mudanças notáveis neste projeto serão documentadas neste arquivo.

O formato é baseado em [Keep a Changelog](https://keepachangelog.com/pt-BR/1.0.0/),
e este projeto adere ao [Semantic Versioning](https://semver.org/lang/pt-BR/).

## [1.2.0] - 2025-12-11

### 🏠 Adicionado - Homepage Completa
- **Template front-page.php**: Nova homepage dedicada com layout profissional
- **Hero Section**: Notícia principal grande com imagem e overlay
- **Grid Lateral**: 4 notícias secundárias ao lado do hero
- **Seção "Não Perca"**: Grid de 6 notícias em destaque
- **Seção Vídeos**: Grid de 4 vídeos com ícone de play
- **Últimas Notícias**: Lista de 10 notícias mais recentes
- **CSS Homepage**: Novo arquivo `homepage-layout.css` com estilos dedicados

### 📝 Arquivos Criados
- `front-page.php` - Template da homepage (320 linhas)
- `assets/css/homepage-layout.css` - Estilos do layout homepage (450 linhas)

### 🔧 Modificado
- `functions.php` - Carregamento condicional do CSS da homepage
- `style.css` - Descrição atualizada e versão 1.2.0

### 🎨 Melhorado
- Homepage agora tem 6 seções distintas
- Layout mais próximo de grandes portais
- Hierarquia visual profissional
- Experiência de navegação aprimorada

---

## [1.1.0] - 2025-12-11

### 🎨 Adicionado - Estilo G1
- **Breaking News Bar**: Barra vermelha com últimas notícias em rotação automática
- **Seções por Categoria**: Layout estilo G1 com categorias coloridas na homepage
- **Timestamps Relativos**: Sistema "há X minutos/horas/dias" em todos os posts
- **Widget "Mais Lidas"**: Widget com numeração grande estilo G1
- **Post Badges**: Badges para VÍDEO, AO VIVO, URGENTE sobre imagens
- **CSS G1**: Novo arquivo `g1-style.css` com todos os estilos específicos

### 📝 Arquivos Criados
- `assets/css/g1-style.css` - Estilos do layout G1
- `template-parts/breaking-news.php` - Componente barra de notícias
- `template-parts/category-sections.php` - Seções por categoria
- `inc/widgets/most-read-widget.php` - Widget mais lidas
- `MELHORIAS-G1.txt` - Documentação das melhorias
- `CHANGELOG.md` - Este arquivo

### 🔧 Modificado
- `index.php` - Integração dos componentes G1 (breaking news e seções)
- `functions.php` - Carregamento do CSS G1 e widget
- `inc/template-tags.php` - Adição da função `news_soberano_time_ago()`

### 🎨 Melhorado
- Layout da homepage mais denso e informativo
- Hierarquia visual aprimorada
- Experiência de usuário similar aos grandes portais

---

## [1.0.0] - 2025-12-11

### 🎉 Lançamento Inicial

#### ✨ Funcionalidades Principais
- Layout moderno responsivo (mobile-first)
- Cores personalizadas: Verde (#6cb83b) e Marrom (#8b6f47)
- Modo escuro/claro com toggle
- Sistema de posts em destaque
- Grid de notícias configurável (2, 3 ou 4 colunas)

#### ⚡ Performance
- Lazy loading de imagens nativo
- CSS e JavaScript otimizados
- Compatibilidade com WP Rocket
- Core Web Vitals otimizado
- Remoção de scripts desnecessários (emojis, etc)

#### 🔍 SEO
- Schema.org markup (NewsArticle)
- Meta tags Open Graph e Twitter Cards
- Compatibilidade total com Rank Math SEO
- Breadcrumbs integrados
- Sitemap XML ready

#### 📱 AMP
- Suporte completo a páginas AMP
- Templates AMP customizados
- Estilos otimizados para AMP
- Analytics integrado no AMP

#### 🎯 Funcionalidades de Conteúdo
- Sistema de visualizações de posts
- Widget de posts populares
- Posts relacionados automáticos
- Compartilhamento social (Facebook, Twitter, WhatsApp, Email)
- Tempo estimado de leitura
- Box de autor
- Sistema de comentários estilizado

#### 🎨 Design
- Header com gradiente verde/marrom
- Footer em três colunas
- Sidebar personalizável
- Busca avançada com modal
- Menu mobile responsivo
- Botão "Voltar ao topo"
- Animações suaves ao scroll

#### 📁 Estrutura de Arquivos
```
news-soberano/
├── style.css (CSS principal)
├── functions.php (Funcionalidades)
├── index.php (Template homepage)
├── single.php (Template post individual)
├── archive.php (Template arquivo)
├── header.php
├── footer.php
├── sidebar.php
├── 404.php
├── comments.php
├── searchform.php
├── assets/
│   ├── css/
│   │   └── additional-styles.css
│   ├── js/
│   │   ├── main.js
│   │   └── lazyload.js
│   └── images/
├── inc/
│   ├── customizer.php
│   ├── template-tags.php
│   └── amp-support.php
└── README.md
```

#### 🔌 Plugins Compatíveis
- ✅ WP Rocket (Cache e otimização)
- ✅ Rank Math SEO (SEO avançado)
- ✅ AMP (Páginas aceleradas)
- ✅ Contact Form 7
- ✅ Akismet

#### 🌐 Requisitos
- WordPress: 5.8+
- PHP: 7.4+
- Recomendado: MySQL 5.7+ ou MariaDB 10.3+

---

## Formato de Versionamento

**MAJOR.MINOR.PATCH**

- **MAJOR**: Mudanças incompatíveis com versões anteriores
- **MINOR**: Novas funcionalidades compatíveis com versões anteriores
- **PATCH**: Correções de bugs compatíveis com versões anteriores

### Tipos de Mudanças
- `Adicionado` - Novas funcionalidades
- `Modificado` - Mudanças em funcionalidades existentes
- `Depreciado` - Funcionalidades que serão removidas em breve
- `Removido` - Funcionalidades removidas
- `Corrigido` - Correções de bugs
- `Segurança` - Correções de vulnerabilidades

---

## Links
- [Site Oficial](https://jornal.camposoberano.com.br)
- [Documentação](README.md)
- [Guia de Instalação](../INSTRUCOES-DE-INSTALACAO.md)
