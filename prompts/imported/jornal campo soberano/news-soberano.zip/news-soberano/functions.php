<?php
/**
 * News Soberano Theme Functions
 *
 * @package News_Soberano
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// Define constantes do tema
define('NEWS_SOBERANO_VERSION', '1.2.0');
define('NEWS_SOBERANO_DIR', get_template_directory());
define('NEWS_SOBERANO_URI', get_template_directory_uri());

/**
 * Configuração inicial do tema
 */
function news_soberano_setup() {
    // Suporte a tradução
    load_theme_textdomain('news-soberano', NEWS_SOBERANO_DIR . '/languages');

    // Suporte a feed automático
    add_theme_support('automatic-feed-links');

    // Suporte a título dinâmico
    add_theme_support('title-tag');

    // Suporte a imagens destacadas
    add_theme_support('post-thumbnails');
    set_post_thumbnail_size(800, 450, true);

    // Tamanhos de imagem personalizados
    add_image_size('news-featured', 1200, 600, true);
    add_image_size('news-large', 800, 450, true);
    add_image_size('news-medium', 400, 225, true);
    add_image_size('news-thumb', 200, 150, true);

    // Suporte a HTML5
    add_theme_support('html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
        'style',
        'script'
    ));

    // Suporte a logotipo customizado
    add_theme_support('custom-logo', array(
        'height'      => 80,
        'width'       => 200,
        'flex-height' => true,
        'flex-width'  => true,
    ));

    // Suporte a cores customizadas
    add_theme_support('editor-color-palette', array(
        array(
            'name'  => __('Verde Primário', 'news-soberano'),
            'slug'  => 'primary-green',
            'color' => '#6cb83b',
        ),
        array(
            'name'  => __('Marrom Primário', 'news-soberano'),
            'slug'  => 'primary-brown',
            'color' => '#8b6f47',
        ),
    ));

    // Registrar menus
    register_nav_menus(array(
        'primary' => __('Menu Principal', 'news-soberano'),
        'footer'  => __('Menu Rodapé', 'news-soberano'),
    ));

    // Suporte a refresh seletivo no Customizer
    add_theme_support('customize-selective-refresh-widgets');

    // Suporte a post formats
    add_theme_support('post-formats', array(
        'video',
        'gallery',
        'quote',
    ));

    // Suporte a AMP
    add_theme_support('amp', array(
        'paired' => true,
    ));
}
add_action('after_setup_theme', 'news_soberano_setup');

/**
 * Configurar largura do conteúdo
 */
function news_soberano_content_width() {
    $GLOBALS['content_width'] = apply_filters('news_soberano_content_width', 1280);
}
add_action('after_setup_theme', 'news_soberano_content_width', 0);

/**
 * Enfileirar estilos e scripts
 */
function news_soberano_scripts() {
    // Google Fonts
    wp_enqueue_style(
        'news-soberano-fonts',
        'https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700&display=swap',
        array(),
        null
    );

    // Estilo principal
    wp_enqueue_style(
        'news-soberano-style',
        get_stylesheet_uri(),
        array(),
        NEWS_SOBERANO_VERSION
    );

    // Estilos adicionais
    wp_enqueue_style(
        'news-soberano-additional',
        NEWS_SOBERANO_URI . '/assets/css/additional-styles.css',
        array('news-soberano-style'),
        NEWS_SOBERANO_VERSION
    );

    // Estilos G1
    wp_enqueue_style(
        'news-soberano-g1',
        NEWS_SOBERANO_URI . '/assets/css/g1-style.css',
        array('news-soberano-additional'),
        NEWS_SOBERANO_VERSION
    );

    // Estilos Homepage Layout
    if (is_front_page()) {
        wp_enqueue_style(
            'news-soberano-homepage',
            NEWS_SOBERANO_URI . '/assets/css/homepage-layout.css',
            array('news-soberano-g1'),
            NEWS_SOBERANO_VERSION
        );
    }

    // Script principal
    wp_enqueue_script(
        'news-soberano-script',
        NEWS_SOBERANO_URI . '/assets/js/main.js',
        array(),
        NEWS_SOBERANO_VERSION,
        true
    );

    // Lazy loading para imagens
    wp_enqueue_script(
        'news-soberano-lazyload',
        NEWS_SOBERANO_URI . '/assets/js/lazyload.js',
        array(),
        NEWS_SOBERANO_VERSION,
        true
    );

    // Comentários
    if (is_singular() && comments_open() && get_option('thread_comments')) {
        wp_enqueue_script('comment-reply');
    }

    // Passar dados para JavaScript
    wp_localize_script('news-soberano-script', 'newsSoberanoData', array(
        'ajaxUrl' => admin_url('admin-ajax.php'),
        'nonce'   => wp_create_nonce('news-soberano-nonce'),
        'theme'   => get_option('news_soberano_theme', 'light'),
    ));
}
add_action('wp_enqueue_scripts', 'news_soberano_scripts');

/**
 * Registrar áreas de widgets
 */
function news_soberano_widgets_init() {
    // Sidebar principal
    register_sidebar(array(
        'name'          => __('Sidebar Principal', 'news-soberano'),
        'id'            => 'sidebar-1',
        'description'   => __('Aparece na lateral das páginas de posts e archives.', 'news-soberano'),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ));

    // Footer widgets
    for ($i = 1; $i <= 3; $i++) {
        register_sidebar(array(
            'name'          => sprintf(__('Rodapé %d', 'news-soberano'), $i),
            'id'            => 'footer-' . $i,
            'description'   => sprintf(__('Área de widget %d do rodapé.', 'news-soberano'), $i),
            'before_widget' => '<div id="%1$s" class="footer-widget widget %2$s">',
            'after_widget'  => '</div>',
            'before_title'  => '<h3 class="widget-title">',
            'after_title'   => '</h3>',
        ));
    }
}
add_action('widgets_init', 'news_soberano_widgets_init');

/**
 * Adicionar classes ao body
 */
function news_soberano_body_classes($classes) {
    // Adiciona classe se não houver sidebar
    if (!is_active_sidebar('sidebar-1')) {
        $classes[] = 'no-sidebar';
    }

    // Adiciona classe do tema escuro/claro
    $theme = get_option('news_soberano_theme', 'light');
    $classes[] = 'theme-' . $theme;

    return $classes;
}
add_filter('body_class', 'news_soberano_body_classes');

/**
 * Customizar excerpt
 */
function news_soberano_custom_excerpt_length($length) {
    return 25;
}
add_filter('excerpt_length', 'news_soberano_custom_excerpt_length');

function news_soberano_excerpt_more($more) {
    return '...';
}
add_filter('excerpt_more', 'news_soberano_excerpt_more');

/**
 * Função para obter tempo de leitura estimado
 */
function news_soberano_reading_time() {
    $content = get_post_field('post_content', get_the_ID());
    $word_count = str_word_count(strip_tags($content));
    $reading_time = ceil($word_count / 200); // 200 palavras por minuto

    return sprintf(
        _n('%s min de leitura', '%s mins de leitura', $reading_time, 'news-soberano'),
        $reading_time
    );
}

/**
 * Função para obter visualizações do post
 */
function news_soberano_get_post_views($post_id) {
    $count = get_post_meta($post_id, 'news_soberano_post_views', true);
    return $count ? $count : 0;
}

function news_soberano_set_post_views($post_id) {
    $count = news_soberano_get_post_views($post_id);
    $count++;
    update_post_meta($post_id, 'news_soberano_post_views', $count);
}

// Remover prefetch do post quando visualizado
remove_action('wp_head', 'adjacent_posts_rel_link_wp_head', 10, 0);

/**
 * Adicionar schema.org markup para SEO
 */
function news_soberano_schema_markup() {
    if (is_single()) {
        $schema = array(
            '@context'      => 'https://schema.org',
            '@type'         => 'NewsArticle',
            'headline'      => get_the_title(),
            'datePublished' => get_the_date('c'),
            'dateModified'  => get_the_modified_date('c'),
            'author'        => array(
                '@type' => 'Person',
                'name'  => get_the_author(),
            ),
            'publisher'     => array(
                '@type' => 'Organization',
                'name'  => get_bloginfo('name'),
                'logo'  => array(
                    '@type' => 'ImageObject',
                    'url'   => get_site_icon_url(),
                ),
            ),
        );

        if (has_post_thumbnail()) {
            $schema['image'] = get_the_post_thumbnail_url(get_the_ID(), 'full');
        }

        echo '<script type="application/ld+json">' . wp_json_encode($schema) . '</script>';
    }
}
add_action('wp_head', 'news_soberano_schema_markup');

/**
 * Adicionar meta tags Open Graph para compartilhamento social
 */
function news_soberano_add_og_tags() {
    if (is_single()) {
        ?>
        <meta property="og:type" content="article" />
        <meta property="og:title" content="<?php echo esc_attr(get_the_title()); ?>" />
        <meta property="og:description" content="<?php echo esc_attr(get_the_excerpt()); ?>" />
        <meta property="og:url" content="<?php echo esc_url(get_permalink()); ?>" />
        <meta property="og:site_name" content="<?php echo esc_attr(get_bloginfo('name')); ?>" />
        <?php if (has_post_thumbnail()) : ?>
        <meta property="og:image" content="<?php echo esc_url(get_the_post_thumbnail_url(get_the_ID(), 'full')); ?>" />
        <?php endif; ?>

        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content="<?php echo esc_attr(get_the_title()); ?>" />
        <meta name="twitter:description" content="<?php echo esc_attr(get_the_excerpt()); ?>" />
        <?php if (has_post_thumbnail()) : ?>
        <meta name="twitter:image" content="<?php echo esc_url(get_the_post_thumbnail_url(get_the_ID(), 'full')); ?>" />
        <?php endif; ?>
        <?php
    }
}
add_action('wp_head', 'news_soberano_add_og_tags');

/**
 * AJAX: Alternar tema escuro/claro
 */
function news_soberano_toggle_theme() {
    check_ajax_referer('news-soberano-nonce', 'nonce');

    $current_theme = get_option('news_soberano_theme', 'light');
    $new_theme = ($current_theme === 'light') ? 'dark' : 'light';

    update_option('news_soberano_theme', $new_theme);

    wp_send_json_success(array('theme' => $new_theme));
}
add_action('wp_ajax_news_soberano_toggle_theme', 'news_soberano_toggle_theme');
add_action('wp_ajax_nopriv_news_soberano_toggle_theme', 'news_soberano_toggle_theme');

/**
 * Otimizações de performance
 */
// Remover query strings de recursos estáticos
function news_soberano_remove_query_strings($src) {
    if (strpos($src, '?ver=')) {
        $src = remove_query_arg('ver', $src);
    }
    return $src;
}
add_filter('style_loader_src', 'news_soberano_remove_query_strings', 10, 1);
add_filter('script_loader_src', 'news_soberano_remove_query_strings', 10, 1);

// Desabilitar emojis para performance
function news_soberano_disable_emojis() {
    remove_action('wp_head', 'print_emoji_detection_script', 7);
    remove_action('admin_print_scripts', 'print_emoji_detection_script');
    remove_action('wp_print_styles', 'print_emoji_styles');
    remove_action('admin_print_styles', 'print_emoji_styles');
    remove_filter('the_content_feed', 'wp_staticize_emoji');
    remove_filter('comment_text_rss', 'wp_staticize_emoji');
    remove_filter('wp_mail', 'wp_staticize_emoji_for_email');
}
add_action('init', 'news_soberano_disable_emojis');

/**
 * Compatibilidade com WP Rocket
 */
function news_soberano_rocket_compatibility() {
    // Adicionar suporte para lazy loading de imagens
    add_filter('rocket_lazyload_html', '__return_true');

    // Minificar CSS inline
    add_filter('rocket_minify_inline_css', '__return_true');

    // Minificar JS inline
    add_filter('rocket_minify_inline_js', '__return_true');
}
add_action('init', 'news_soberano_rocket_compatibility');

/**
 * Compatibilidade com Rank Math SEO
 */
function news_soberano_rankmath_compatibility() {
    // Adicionar breadcrumbs do Rank Math
    add_theme_support('rank-math-breadcrumbs');
}
add_action('after_setup_theme', 'news_soberano_rankmath_compatibility');

/**
 * Widget customizado: Posts Populares
 */
class News_Soberano_Popular_Posts_Widget extends WP_Widget {

    public function __construct() {
        parent::__construct(
            'news_soberano_popular_posts',
            __('Posts Populares (News Soberano)', 'news-soberano'),
            array('description' => __('Exibe os posts mais visualizados', 'news-soberano'))
        );
    }

    public function widget($args, $instance) {
        echo $args['before_widget'];

        if (!empty($instance['title'])) {
            echo $args['before_title'] . apply_filters('widget_title', $instance['title']) . $args['after_title'];
        }

        $number = !empty($instance['number']) ? absint($instance['number']) : 5;

        $popular_posts = new WP_Query(array(
            'posts_per_page' => $number,
            'meta_key'       => 'news_soberano_post_views',
            'orderby'        => 'meta_value_num',
            'order'          => 'DESC',
        ));

        if ($popular_posts->have_posts()) {
            echo '<ul class="popular-posts-list">';
            while ($popular_posts->have_posts()) {
                $popular_posts->the_post();
                ?>
                <li class="popular-post-item">
                    <?php if (has_post_thumbnail()) : ?>
                        <a href="<?php the_permalink(); ?>" class="popular-post-thumb">
                            <?php the_post_thumbnail('news-thumb'); ?>
                        </a>
                    <?php endif; ?>
                    <div class="popular-post-content">
                        <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                        <span class="popular-post-date"><?php echo get_the_date(); ?></span>
                    </div>
                </li>
                <?php
            }
            echo '</ul>';
            wp_reset_postdata();
        }

        echo $args['after_widget'];
    }

    public function form($instance) {
        $title = !empty($instance['title']) ? $instance['title'] : __('Posts Populares', 'news-soberano');
        $number = !empty($instance['number']) ? absint($instance['number']) : 5;
        ?>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title')); ?>">
                <?php _e('Título:', 'news-soberano'); ?>
            </label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>"
                   name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text"
                   value="<?php echo esc_attr($title); ?>">
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('number')); ?>">
                <?php _e('Número de posts:', 'news-soberano'); ?>
            </label>
            <input class="tiny-text" id="<?php echo esc_attr($this->get_field_id('number')); ?>"
                   name="<?php echo esc_attr($this->get_field_name('number')); ?>" type="number"
                   step="1" min="1" value="<?php echo esc_attr($number); ?>" size="3">
        </p>
        <?php
    }

    public function update($new_instance, $old_instance) {
        $instance = array();
        $instance['title'] = (!empty($new_instance['title'])) ? sanitize_text_field($new_instance['title']) : '';
        $instance['number'] = (!empty($new_instance['number'])) ? absint($new_instance['number']) : 5;
        return $instance;
    }
}

function news_soberano_register_widgets() {
    register_widget('News_Soberano_Popular_Posts_Widget');
}
add_action('widgets_init', 'news_soberano_register_widgets');

/**
 * Incluir arquivos adicionais
 */
require_once NEWS_SOBERANO_DIR . '/inc/customizer.php';
require_once NEWS_SOBERANO_DIR . '/inc/template-tags.php';
require_once NEWS_SOBERANO_DIR . '/inc/amp-support.php';
require_once NEWS_SOBERANO_DIR . '/inc/widgets/most-read-widget.php';
